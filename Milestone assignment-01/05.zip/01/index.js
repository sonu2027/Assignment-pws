let enteredPassword=prompt("Enter password: ")
let confirmedPassword=prompt("Confirm password: ")
if(enteredPassword==confirmedPassword){
    console.log("Password validation Successful")
}
else{
    console.log("Password didn't match")
}