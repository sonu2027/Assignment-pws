function economy() {
  let x = document.getElementsByTagName("input");
  let y = document.getElementsByTagName("span");
  y[0].innerText = x[0].value * 4000;
}
function midsize() {
  let x = document.getElementsByTagName("input");
  let y = document.getElementsByTagName("span");
  y[0].innerText = x[0].value * 10000;
}
function luxury() {
  let x = document.getElementsByTagName("input");
  let y = document.getElementsByTagName("span");
  y[0].innerText = x[0].value * 20000;
}
