for(let i=0; i<20; i++){
    let ranNo= (100*(Math.random(1,100).toFixed(2))).toFixed(0)
    console.log(ranNo);
}
